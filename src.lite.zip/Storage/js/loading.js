    const texts = [
      'Интересный факт: Изначально в игре не было меню.',
      'Интересный факт: Режимы игры которые вы знаете могли быть сезонами.',
      'Ленивый факт: Экстрим всё еще не готов.'
    ];

    function getRandomText() {
      return texts[Math.floor(Math.random() * texts.length)];
    }

    document.addEventListener('DOMContentLoaded', function() {
      const dynamicTextElement = document.getElementById('loadingText');
      const randomText = getRandomText();

      dynamicTextElement.textContent = randomText;

      if (randomText === '993') {
        dynamicTextElement.style.color = '#D500FF'; // Устанавливаем фиолетовый цвет
      }
    });

    document.addEventListener("DOMContentLoaded", function() {
        const percentageElement = document.getElementById("percentage");

        function updatePercentage() {
            let startTime;
            const duration = 6000; // 8 seconds

            function animatePercentage(timestamp) {
                if (!startTime) {
                    startTime = timestamp;
                }

                const progress = timestamp - startTime;
                const percentage = Math.min(100, (progress / duration) * 100);

                percentageElement.textContent = `${percentage.toFixed(0)}%`;

                if (progress < duration) {
                    requestAnimationFrame(animatePercentage);
                }
            }

            requestAnimationFrame(animatePercentage);
        }

        updatePercentage();
    });