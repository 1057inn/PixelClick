    const texts = [
      'Chloropicrin',
      'Больше Дальше!',
      'Чипи чипи чапа чапа',
      'Это сплеш текст',
      'Дальше Больше!',
      'Айн цвайн.. ой',
      '1+1=3',
      '993',
      '...',
      'PixelClick Standard',
      'Больше Дальше!',
      '/?',
      '*',
      'Дальше Больше!',
      'Отрицание первая стадия принятия',
      '/ban Rovisa 999d idiot',
      'Как меня зовут?',
       '1.7 Release',
      'Больше Дальше!',
      'Чипи чипи чапа чапа',
      'thank you vizer',
      'Дальше Больше!',
      'Курнул но вроде не навоз',
      'Кентишка дунул паравоз',
      'Завозов не будет.',
      'Система достижений?',
      '1057-993',
      'Festive on ❌❌❌'
    ];

    function getRandomText() {
      return texts[Math.floor(Math.random() * texts.length)];
    }

    document.addEventListener('DOMContentLoaded', function() {
      const dynamicTextElement = document.getElementById('splash');
      const randomText = getRandomText();

      dynamicTextElement.textContent = randomText;

      if (randomText === '993') {
        dynamicTextElement.style.color = '#D500FF'; // Устанавливаем фиолетовый цвет
      }
      if (randomText === '...') {
        dynamicTextElement.style.color = '#D500FF'; // Устанавливаем фиолетовый цвет
      }
      if (randomText === '1057-993') {
        dynamicTextElement.style.color = '#646464'; // Устанавливаем фиолетовый цвет
      }
      if (randomText === 'thank you vizer') {
        dynamicTextElement.style.color = '#FF0072'; // Устанавливаем фиолетовый цвет
      }
    });