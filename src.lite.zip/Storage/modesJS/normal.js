;let customLocalStorageKey = 'normal-002037';

let counter = (localStorage.getItem(customLocalStorageKey)) ? parseInt(localStorage.getItem(customLocalStorageKey)) : 0;
let factor  = 1;
let background = 0;

document.querySelector('#button').addEventListener('click', function()
{
    counter += factor;
    document.querySelector("#counter").textContent = parseInt(counter);

    let vfx = document.querySelector(".button-vfx");
    vfx.style.backgroundImage = 'url("./img/buttonVfx.gif")';
    setTimeout (function() {
        vfx.style.backgroundImage = 'unset';
    }, 100);
    saveMain();
});

class Bonus
{
    constructor(name, cost, factor, id, automate, own = 0) 
    {
        this.name = name;
        this.cost = cost;
        this.factor = factor;
        this.own = 0;
        this.id = id;
        this.automate = automate;

        let tags = '<div class="'+this.id+' bonus" href="#"> <div class="bunus-vfx"></div> <h2>'+this.name+'</h2> <p> Куплено раз: <span class="multiply_counter">'+this.own+'</span> </p> <p> Стоимость: <span class="multiply_cost">'+this.cost+'</span> </p> </div>';
        document.querySelector(".b-three").innerHTML += tags;
        
        this.element = document.querySelector("."+this.id);

        if (this.automate == true)
        {
            setInterval(() =>
            {
                counter += background;
                this.refresh();    
            }, 1 * 1000);
        }

        for (let i = 0; i < own; i++)
        {
            this.buy(true);
        }
    }

    buy(instant = false)
    {
        if (counter >= this.cost || instant)
        {
            if (this.automate)
                background += this.factor;
            else 
                factor += this.factor;

            if (!instant)
            {
                counter -= this.cost;
                this.animation();
            }
                
            this.own += 1;
            this.factor += 0.1;
            this.cost *= 1.5;
            this.refresh();

            localStorage.setItem(customLocalStorageKey + '_' + this.id, this.own);
        }
    }

    refresh()
    {
        document.querySelector("."+this.id+" .multiply_counter").textContent = (this.own).toFixed(0);
        document.querySelector("."+this.id+" .multiply_cost").textContent = (this.cost).toFixed(0);
        document.querySelector("#counter").textContent = parseInt(counter);
        document.querySelector("#factor").textContent = factor.toFixed(1);
        document.querySelector("#background").textContent = background.toFixed(0);
    }

    listener()
    {
        document.querySelector("."+this.id).addEventListener('click', () => { this.buy(); });
    }

    animation()
    {
        let vfx = document.querySelector("."+this.id).querySelector(".bunus-vfx");
        vfx.style.backgroundImage = 'url("./img/bonusVfx.gif")';
        setTimeout (function() {
            vfx.style.backgroundImage = 'unset';
        }, 100);
    }
}

// (name, cost, factor, id, automate~) 
let lvl1c = new Bonus('Сила клика 1 уровня', 30, 0.1, 'lvl1c', false, (localStorage.getItem(customLocalStorageKey + '_lvl1c')) ? parseInt(localStorage.getItem(customLocalStorageKey + '_lvl1c')) : 0);
let lvl1m = new Bonus('Mайнер 1 уровня', 150, 1, 'lvl1m', true, (localStorage.getItem(customLocalStorageKey + '_lvl1m')) ? parseInt(localStorage.getItem(customLocalStorageKey + '_lvl1m')) : 0);
let lvl2c = new Bonus('Сила клика 2 уровня', 780, 1.1, 'lvl2c', false, (localStorage.getItem(customLocalStorageKey + '_lvl2c')) ? parseInt(localStorage.getItem(customLocalStorageKey + '_lvl2c')) : 0);
let lvl2m = new Bonus('Mайнер 2 уровня', 1199, 1, 'lvl2m', true, (localStorage.getItem(customLocalStorageKey + '_lvl2m')) ? parseInt(localStorage.getItem(customLocalStorageKey + '_lvl2m')) : 0);
let lvl3c = new Bonus('Сила клика 3 уровня', 3499, 5, 'lvl3c', false, (localStorage.getItem(customLocalStorageKey + '_lvl3c')) ? parseInt(localStorage.getItem(customLocalStorageKey + '_lvl3c')) : 0);
let lvl3m = new Bonus('Mайнер 3 уровня', 7799, 5, 'lvl3m', true, (localStorage.getItem(customLocalStorageKey + '_lvl3m')) ? parseInt(localStorage.getItem(customLocalStorageKey + '_lvl3m')) : 0);
let lvl4c = new Bonus('Сила клика 4 уровня', 59999, 12, 'lvl4c', false, (localStorage.getItem(customLocalStorageKey + '_lvl4c')) ? parseInt(localStorage.getItem(customLocalStorageKey + '_lvl4c')) : 0);
let lvl4m = new Bonus('Mайнер 4 уровня', 145799, 15, 'lvl4m', true, (localStorage.getItem(customLocalStorageKey + '_lvl4m')) ? parseInt(localStorage.getItem(customLocalStorageKey + '_lvl4m')) : 0);
let lvl993c = new Bonus('Сила клика 993 уровня', 993993993993993, 550037354838284737272737.55, 'lvl993c', false, (localStorage.getItem(customLocalStorageKey + '_lvl993c')) ? parseInt(localStorage.getItem(customLocalStorageKey + '_lvl993c')) : 0);

lvl1c.listener();
lvl1m.listener();
lvl2c.listener();
lvl2m.listener();
lvl3c.listener();
lvl3m.listener();
lvl4c.listener();
lvl4m.listener();
lvl993c.listener();

function saveMain() {
    localStorage.setItem(customLocalStorageKey, parseInt(counter));
}

setInterval(saveMain, 1000);

let bonusPanel = document.querySelector('.b-three');
let toggleButton = document.querySelector('#bonusbtn'); // Замените 'toggleButton' на ваш реальный идентификатор кнопки

// Инициализация события для кнопки
toggleButton.addEventListener('click', function() {
    toggleBonusPanel();
});

function toggleBonusPanel() {
    if (bonusPanel.style.display === 'none' || bonusPanel.style.display === '') {
        bonusPanel.style.display = 'block';
    } else {
        bonusPanel.style.display = 'none';
    }
}

function toggleBonusPanel() {
    if (bonusPanel.style.display === 'none' || bonusPanel.style.display === '') {
        bonusPanel.style.display = 'block';
    } else {
        bonusPanel.style.display = 'none';
    }
}