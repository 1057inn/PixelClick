;let customLocalStorageKey = 'harder-007073';

let counter = (localStorage.getItem(customLocalStorageKey)) ? parseInt(localStorage.getItem(customLocalStorageKey)) : 0;
let factor  = 1;
let background = 0;

document.querySelector('#button').addEventListener('click', function()
{
    counter += factor;
    document.querySelector("#counter").textContent = parseInt(counter);

    let vfx = document.querySelector(".button-vfx");
    vfx.style.backgroundImage = 'url("./img/buttonVfx.gif")';
    setTimeout (function() {
        vfx.style.backgroundImage = 'unset';
    }, 100);
    saveMain();
});

class Bonus
{
    constructor(name, cost, factor, id, automate, own = 0) 
    {
        this.name = name;
        this.cost = cost;
        this.factor = factor;
        this.own = 0;
        this.id = id;
        this.automate = automate;

        let tags = '<div class="'+this.id+' bonus" href="#"> <div class="bunus-vfx"></div> <h2>'+this.name+'</h2> <p> Куплено раз: <span class="multiply_counter">'+this.own+'</span> </p> <p> Стоимость: <span class="multiply_cost">'+this.cost+'</span> </p> </div>';
        document.querySelector(".b-three").innerHTML += tags;
        
        this.element = document.querySelector("."+this.id);

        if (this.automate == true)
        {
            setInterval(() =>
            {
                counter += background;
                this.refresh();    
            }, 1 * 1000);
        }

        for (let i = 0; i < own; i++)
        {
            this.buy(true);
        }
    }

    buy(instant = false)
    {
        if (counter >= this.cost || instant)
        {
            if (this.automate)
                background += this.factor;
            else 
                factor += this.factor;

            if (!instant)
            {
                counter -= this.cost;
                this.animation();
            }
                
            this.own += 1;
            this.factor += 0.1;
            this.cost *= 1.5;
            this.refresh();

            localStorage.setItem(customLocalStorageKey + '_' + this.id, this.own);
        }
    }

    refresh()
    {
        document.querySelector("."+this.id+" .multiply_counter").textContent = (this.own).toFixed(0);
        document.querySelector("."+this.id+" .multiply_cost").textContent = (this.cost).toFixed(0);
        document.querySelector("#counter").textContent = parseInt(counter);
        document.querySelector("#factor").textContent = factor.toFixed(1);
        document.querySelector("#background").textContent = background.toFixed(0);
    }

    listener()
    {
        document.querySelector("."+this.id).addEventListener('click', () => { this.buy(); });
    }

    animation()
    {
        let vfx = document.querySelector("."+this.id).querySelector(".bunus-vfx");
        vfx.style.backgroundImage = 'url("./img/bonusVfx.gif")';
        setTimeout (function() {
            vfx.style.backgroundImage = 'unset';
        }, 100);
    }
}

// (name, cost, factor, id, automate~) 
let lvl1c = new Bonus('Сила клика 1 уровня', 105, 0.1, 'lvl1c', false, (localStorage.getItem(customLocalStorageKey + '_lvl1c')) ? parseInt(localStorage.getItem(customLocalStorageKey + '_lvl1c')) : 0);
let lvl1m = new Bonus('Mайнер 1 уровня', 1005, 1, 'lvl1m', true, (localStorage.getItem(customLocalStorageKey + '_lvl1m')) ? parseInt(localStorage.getItem(customLocalStorageKey + '_lvl1m')) : 0);
let lvl2c = new Bonus('Сила клика 2 уровня', 2799, 0.1, 'lvl2c', false, (localStorage.getItem(customLocalStorageKey + '_lvl2c')) ? parseInt(localStorage.getItem(customLocalStorageKey + '_lvl2c')) : 0);
let lvl2m = new Bonus('Mайнер 2 уровня', 6199, 1, 'lvl2m', true, (localStorage.getItem(customLocalStorageKey + '_lvl2m')) ? parseInt(localStorage.getItem(customLocalStorageKey + '_lvl2m')) : 0);
let lvl3c = new Bonus('Сила клика 3 уровня', 13499, 1, 'lvl3c', false, (localStorage.getItem(customLocalStorageKey + '_lvl3c')) ? parseInt(localStorage.getItem(customLocalStorageKey + '_lvl3c')) : 0);
let lvl3m = new Bonus('Mайнер 3 уровня', 76799, 5, 'lvl3m', true, (localStorage.getItem(customLocalStorageKey + '_lvl3m')) ? parseInt(localStorage.getItem(customLocalStorageKey + '_lvl3m')) : 0);
let lvl4c = new Bonus('Сила клика 4 уровня', 345799, 5, 'lvl4c', false, (localStorage.getItem(customLocalStorageKey + '_lvl4c')) ? parseInt(localStorage.getItem(customLocalStorageKey + '_lvl4c')) : 0);
let lvl4m = new Bonus('Mайнер 4 уровня', 567000, 15, 'lvl4m', true, (localStorage.getItem(customLocalStorageKey + '_lvl4m')) ? parseInt(localStorage.getItem(customLocalStorageKey + '_lvl4m')) : 0);
let lvl5c = new Bonus('Сила клика 5 уровня', 993000, 25, 'lvl5c', false, (localStorage.getItem(customLocalStorageKey + '_lvl5c')) ? parseInt(localStorage.getItem(customLocalStorageKey + '_lvl5c')) : 0);
let lvl5m = new Bonus('Mайнер 5 уровня', 1230000, 10, 'lvl5m', true, (localStorage.getItem(customLocalStorageKey + '_lvl5m')) ? parseInt(localStorage.getItem(customLocalStorageKey + '_lvl5m')) : 0);
let lvl6c = new Bonus('Сила клика 6 уровня', 1890323, 50, 'lvl6c', false, (localStorage.getItem(customLocalStorageKey + '_lvl6c')) ? parseInt(localStorage.getItem(customLocalStorageKey + '_lvl6c')) : 0);
let lvl6m = new Bonus('Mайнер 6 уровня', 2345000, 20, 'lvl6m', true, (localStorage.getItem(customLocalStorageKey + '_lvl6m')) ? parseInt(localStorage.getItem(customLocalStorageKey + '_lvl6m')) : 0);
let lvl7c = new Bonus('Сила клика 7 уровня', 2993000, 120, 'lvl7c', false, (localStorage.getItem(customLocalStorageKey + '_lvl7c')) ? parseInt(localStorage.getItem(customLocalStorageKey + '_lvl7c')) : 0);
let lvl7m = new Bonus('Mайнер 7 уровня', 3228000, 45, 'lvl7m', true, (localStorage.getItem(customLocalStorageKey + '_lvl7m')) ? parseInt(localStorage.getItem(customLocalStorageKey + '_lvl7m')) : 0);
let lvl8c = new Bonus('Сила клика 8 уровня', 7993000, 450, 'lvl8c', false, (localStorage.getItem(customLocalStorageKey + '_lvl8c')) ? parseInt(localStorage.getItem(customLocalStorageKey + '_lvl8c')) : 0);
let lvl8m = new Bonus('Mайнер 8 уровня', 12993000, 100, 'lvl8m', true, (localStorage.getItem(customLocalStorageKey + '_lvl8m')) ? parseInt(localStorage.getItem(customLocalStorageKey + '_lvl8m')) : 0);
let lvl9c = new Bonus('Сила клика 9 уровня', 45993000, 120, 'lvl9c', false, (localStorage.getItem(customLocalStorageKey + '_lvl9c')) ? parseInt(localStorage.getItem(customLocalStorageKey + '_lvl9c')) : 0);
let lvl9m = new Bonus('Mайнер 9 уровня', 3228000, 45, 'lvl9m', true, (localStorage.getItem(customLocalStorageKey + '_lvl9m')) ? parseInt(localStorage.getItem(customLocalStorageKey + '_lvl9m')) : 0);
let lvl10c = new Bonus('Сила клика 10 уровня', 99993000, 450, 'lvl10c', false, (localStorage.getItem(customLocalStorageKey + '_lvl10c')) ? parseInt(localStorage.getItem(customLocalStorageKey + '_lvl10c')) : 0);
let lvl10m = new Bonus('Mайнер 10 уровня', 101993000, 100, 'lvl10m', true, (localStorage.getItem(customLocalStorageKey + '_lvl10m')) ? parseInt(localStorage.getItem(customLocalStorageKey + '_lvl10m')) : 0);
let lvl993c = new Bonus('Сила клика 993 уровня', 993993993993993, 550037354838284737272737.55, 'lvl993c', false, (localStorage.getItem(customLocalStorageKey + '_lvl993c')) ? parseInt(localStorage.getItem(customLocalStorageKey + '_lvl993c')) : 0);

lvl1c.listener();
lvl1m.listener();
lvl2c.listener();
lvl2m.listener();
lvl3c.listener();
lvl3m.listener();
lvl4c.listener();
lvl4m.listener();
lvl5c.listener();
lvl5m.listener();
lvl6c.listener();
lvl6m.listener();
lvl7c.listener();
lvl7m.listener();
lvl8c.listener();
lvl8m.listener();
lvl993c.listener();

function saveMain() {
    localStorage.setItem(customLocalStorageKey, parseInt(counter));
}

setInterval(saveMain, 1000);

let bonusPanel = document.querySelector('.b-three');
let toggleButton = document.querySelector('#bonusbtn'); // Замените 'toggleButton' на ваш реальный идентификатор кнопки

// Инициализация события для кнопки
toggleButton.addEventListener('click', function() {
    toggleBonusPanel();
});

function toggleBonusPanel() {
    if (bonusPanel.style.display === 'none' || bonusPanel.style.display === '') {
        bonusPanel.style.display = 'block';
    } else {
        bonusPanel.style.display = 'none';
    }
}

function toggleBonusPanel() {
    if (bonusPanel.style.display === 'none' || bonusPanel.style.display === '') {
        bonusPanel.style.display = 'block';
    } else {
        bonusPanel.style.display = 'none';
    }
}