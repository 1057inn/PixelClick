    // Заготовленные тексты
    const texts = [
        'Где пельмени? Что я жрать буду?',
        'Где пельмени? Что я жрать буду?',
        'Где пельмени? Что я жрать буду?',
        'Где пельмени? Что я жрать буду?',
        '😭😭',
        'Я Гитлер',
        'НЕЕЕЕЕЕЕЕЕЕЕЕЕЕ, а пофиг',
        'НЕЕЕЕЕЕЕЕЕЕЕЕЕЕ, а пофиг',
        'НЕЕЕЕЕЕЕЕЕЕЕЕЕЕ, а пофиг',
        'НЕЕЕЕЕЕЕЕЕЕЕЕЕЕ, а пофиг',
    ];

    // Функция для выбора случайного текста
    function getRandomText() {
        return texts[Math.floor(Math.random() * texts.length)];
    }

    // Устанавливаем текст при загрузке страницы
    document.addEventListener('DOMContentLoaded', function() {
        // Получаем элемент, в который будем вставлять текст
        const dynamicTextElement = document.getElementById('dynamicText');

        // Выбираем случайный текст
        const randomText = getRandomText();

        // Устанавливаем текст в элемент
        dynamicTextElement.textContent = randomText;
    });