let customLocalStorageKey = 'chll-00012';
let counter = (localStorage.getItem(customLocalStorageKey)) ? parseInt(localStorage.getItem(customLocalStorageKey)) : 0;
let factor  = 1;
let background = 0;

document.querySelector('#button').addEventListener('click', function() {
    counter += factor;
    document.querySelector("#counter").textContent = parseInt(counter);

    let vfx = document.querySelector(".button-vfx");
    vfx.style.backgroundImage = 'url("./img/buttonVfx.gif")';
    setTimeout(function() {
        vfx.style.backgroundImage = 'unset';
    }, 100);

    // Проверка на достижение 30 кликов
    if (counter === 28) {
        window.location.href = 'winner.html';
    }

});