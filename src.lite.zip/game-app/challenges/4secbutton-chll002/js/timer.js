    // Исходное время в секундах
    let timeLeft = 4;

    // Функция обновления таймера и перенаправления
    function updateTimer() {
        // Обновляем элемент с таймером
        document.getElementById('timer').innerText = timeLeft;

        // Уменьшаем время
        timeLeft--;

        // Если время вышло, перенаправляем пользователя
        if (timeLeft < 0) {
            window.location.href = 'defeat.html';
        } else {
            // Запускаем функцию снова через 1 секунду (1000 миллисекунд)
            setTimeout(updateTimer, 1000);
        }
    }

    // Запускаем таймер
    updateTimer();