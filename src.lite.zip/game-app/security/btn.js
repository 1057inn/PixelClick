    function checkPass2() {
        var correctPassword = "0000";
        var enteredPassword = prompt("Система защиты. Требуется ввести пароль.");

        if (enteredPassword === correctPassword) {
            alert("Пароль найден в базе.");
               window.location.href = "confirm.html"
        } else {
            alert("Пароль не обнаружен в базе.");
            event.preventDefault();
        }
    }

    document.getElementById("securityBTN").addEventListener("click", checkPass2);